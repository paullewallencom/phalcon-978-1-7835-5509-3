<?php
namespace App\Core\Controllers;

class IndexController extends BaseController
{
    public function indexAction()
    {

    }
}
