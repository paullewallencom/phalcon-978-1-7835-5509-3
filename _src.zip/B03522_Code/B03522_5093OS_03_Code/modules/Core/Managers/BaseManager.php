<?php
namespace App\Core\Managers;

class BaseManager extends \Phalcon\Mvc\User\Module
{

}
