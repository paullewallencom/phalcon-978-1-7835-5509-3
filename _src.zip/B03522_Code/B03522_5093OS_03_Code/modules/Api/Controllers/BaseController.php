<?php
namespace App\Api\Controllers;

class BaseController extends \Phalcon\Mvc\Controller
{

}
