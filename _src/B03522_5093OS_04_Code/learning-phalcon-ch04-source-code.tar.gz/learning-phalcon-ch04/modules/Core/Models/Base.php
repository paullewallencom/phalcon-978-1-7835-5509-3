<?php
namespace App\Core\Models;

class Base extends \Phalcon\Mvc\Model
{

}
