<?php
namespace App\Core\Managers;

class BaseManager extends \Phalcon\Mvc\User\Module
{
    /**
     * Save/Create/Update an object
     *
     * @param \Phalcon\Mvc\Model $object
     * @param string $type
     * @throws \Exception
     * @return Object
     */
    public function save($object, $type = 'save')
    {
        switch($type) {
            case 'save':
                $result = $object->save();
                break;
            case 'create':
                $result = $object->create();
                break;
            case 'update':
                $result = $object->update();
                break;
        }

        if (false === $result) {
            foreach ($object->getMessages() as $message) {
                $error[] = (string) $message;
            }

            throw new \Exception(json_encode($error));
        }

        return $object;
    }
}
