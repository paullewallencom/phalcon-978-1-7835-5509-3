<?php
namespace App\Core\Managers;

use \App\Core\Models\Article;
use \App\Core\Models\ArticleTranslation;

class ArticleManager extends BaseManager
{
    public function find($parameters = null)
    {
        return Article::find($parameters);
    }

    /**
     * Create a new article
     *
     * @param  array                           $data
     * @param  string                          $language
     * @return string|\App\Core\Models\Article
     */
    public function create($input_data)
    {
        $default_data = array(
            'article_user_id' => 1,
            'article_is_published' => 0,
            'translations' => array(
                'en' => array(
                    'article_translation_short_title' => 'Short title',
                    'article_translation_long_title' => 'Long title',
                    'article_translation_description' => 'Description',
                    'article_translation_slug' => '',
                    'article_translation_lang' => 'en',
                )
            ),
            'categories' => array()
        );

        $data = array_merge($default_data, $input_data);

        $article = new Article();
        $article->setArticleUserId($data['article_user_id']);
        $article->setArticleIsPublished($data['article_is_published']);

        $articleTranslations = array();

        foreach ($data['translations'] as $lang => $translation) {
            $tmp = new ArticleTranslation();
            $tmp->assign($translation);
            array_push($articleTranslations, $tmp);
        }

        $article->translations = $articleTranslations;

        return $this->save($article, 'create');
    }

    /**
     * Update an existing article
     *
     * @param  number     $id
     * @param  array      $data
     * @throws \Exception
     * @return unknown
     */
    public function update($id, $data)
    {
        $article = Article::findFirstById($id);

        if (!$article) {
            throw new \Exception('Article not found', 404);
        }

        $article->setArticleShortTitle($data['article_short_title']);
        $article->setUpdatedAt(new \Phalcon\Db\RawValue('NOW()'));

        if (false === $article->update()) {
            foreach ($article->getMessages() as $message) {
                $error[] = (string) $message;
            }

            throw new \Exception(json_encode($error));

        }

        return $article;
    }

    /**
     * Delete articles
     *
     * @param  number     $id
     * @throws \Exception
     * @return boolean
     */
    public function delete($id)
    {
        $article = Article::findFirstById($id);

        if (!$article) {
            throw new \Exception('Article not found', 404);
        }

        if (false === $article->delete()) {
            foreach ($article->getMessages() as $message) {
                $error[] = (string) $message;
            }

            throw new \Exception(json_encode($error));
        }

        return true;
    }

}
