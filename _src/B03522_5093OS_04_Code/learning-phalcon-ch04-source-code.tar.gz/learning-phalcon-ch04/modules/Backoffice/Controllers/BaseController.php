<?php
namespace App\Backoffice\Controllers;

class BaseController extends \Phalcon\Mvc\Controller
{

}
