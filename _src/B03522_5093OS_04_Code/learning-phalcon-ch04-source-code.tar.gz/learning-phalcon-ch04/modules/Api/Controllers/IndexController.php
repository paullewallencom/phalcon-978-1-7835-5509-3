<?php
namespace App\Api\Controllers;

class IndexController extends BaseController
{
    public function indexAction()
    {

    }
}
