<?php
namespace App\Frontend\Controllers;

class BaseController extends \Phalcon\Mvc\Controller
{

}
