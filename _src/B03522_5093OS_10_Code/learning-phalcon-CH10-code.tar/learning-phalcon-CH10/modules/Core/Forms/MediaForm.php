<?php
namespace App\Core\Forms;

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\File;
use Phalcon\Forms\Element\Submit;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Identical;

class MediaForm extends Form
{
    public function initialize($entity = null, $options = null)
    {
        $file = new File('file', array(
            'placeholder' => 'Upload file',
        ));

        $file->addValidators(array(
            new PresenceOf(array(
                'message' => 'File is required',
            ))
        ));

        $this->add($file);

        //CSRF
        $csrf = new Hidden('csrf');

        $csrf->addValidator(
            new Identical(array(
                'value' => $this->security->getSessionToken(),
                'message' => 'CSRF validation failed',
            ))
        );

        $this->add($csrf);

        $this->add(new Submit('upload', array(
            'class' => 'btn btn-lg btn-primary btn-block',
        )));
    }
}
