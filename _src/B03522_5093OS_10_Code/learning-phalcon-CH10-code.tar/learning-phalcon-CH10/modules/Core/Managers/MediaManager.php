<?php
namespace App\Core\Managers;

class MediaManager extends BaseManager
{
    /**
     * Crop to fit method with GD
     *
     * @param string $source
     * @param string $dest
     * @param number $new_width
     * @param number $new_height
     * @param number $quality
     * @return boolean
     */
    public function cropToFit($source, $dest, $new_width, $new_height, $quality = 100)
    {
        $image = new \Phalcon\Image\Adapter\GD($source);
        $source_height = $image->getHeight();
        $source_width  = $image->getWidth();
        $source_aspect_ratio  = $source_width / $source_height;
        $desired_aspect_ratio = $new_width / $new_height;

        if ($source_aspect_ratio > $desired_aspect_ratio) {
            $temp_height = $new_height;
            $temp_width  = ( int ) ($new_height * $source_aspect_ratio);
        } else {
            $temp_width  = $new_width;
            $temp_height = ( int ) ($new_width / $source_aspect_ratio);
        }

        $x0 = ($temp_width - $new_width) / 2;
        $y0 = ($temp_height - $new_height) / 2;

        $image->resize($temp_width, $temp_height)->crop($new_width, $new_height, $x0, $y0);

        return $image->save($dest, $quality);
    }
}
?>
