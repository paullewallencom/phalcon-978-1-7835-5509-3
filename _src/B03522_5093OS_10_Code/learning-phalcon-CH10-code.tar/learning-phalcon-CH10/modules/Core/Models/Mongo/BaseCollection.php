<?php
namespace App\Core\Models\Mongo;

class BaseCollection extends \Phalcon\Mvc\Collection
{

}
