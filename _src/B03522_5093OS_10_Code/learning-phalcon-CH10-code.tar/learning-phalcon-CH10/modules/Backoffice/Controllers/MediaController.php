<?php
namespace App\Backoffice\Controllers;

use App\Core\Forms\MediaForm;

class MediaController extends BaseController
{
    private $valid_mime = [
        'image/jpeg'
    ];

    private $max_size = 125000;

    public function addAction()
    {
        $this->view->form = new MediaForm();
    }

    public function uploadAction()
    {
        if (true == $this->request->hasFiles() && $this->request->isPost()) {
            $upload_dir = __DIR__ . '/../../../public/uploads/';

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755);
            }

            foreach ($this->request->getUploadedFiles() as $file) {

                if (!in_array($file->getRealType(), $this->valid_mime)) {
                    $this->flashSession->error($file->getName().' is invalid');
                    continue;
                }

                if ($file->getSize() > $this->max_size) {
                    $this->flashSession->error($file->getName().' is too big');
                    continue;
                }

                $file->moveTo($upload_dir . $file->getName());
                $this->flashSession->success($file->getName().' has been successfully uploaded.');
            }

            $this->response->redirect('media/add');
        }
    }
}
