<?php
namespace App\Core\Controllers;

class BaseController extends \Phalcon\Mvc\Controller
{
}
