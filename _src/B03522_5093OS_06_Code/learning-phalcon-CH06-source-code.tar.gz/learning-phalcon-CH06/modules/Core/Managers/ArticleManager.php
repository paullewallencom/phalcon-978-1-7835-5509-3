<?php
namespace App\Core\Managers;

use App\Core\Models\Article;
use App\Core\Models\ArticleTranslation;
use App\Core\Models\Category;
use App\Core\Models\Hashtag;
use App\Core\Models\User;

class ArticleManager extends BaseManager
{
    public function find($parameters = null)
    {
        return Article::find($parameters);
    }

    /**
     * Get articles from database - REST ready
     * @param array $parameters
     * @param array $options
     */
    public function restGet(array $parameters = null, array $options = null, $page = 1, $limit = 10)
    {
        $articles = $this->find($parameters);

        $result = $articles->filter(function ($article) {
            return $article->toArray();
        });

        $paginator = new \Phalcon\Paginator\Adapter\NativeArray([
            'data'  => $result,
            'limit' => $limit,
            'page'  => $page,
        ]);

        $data = $paginator->getPaginate();

        if ($data->total_items > 0) {
            return $data;
        }

        if (isset($parameters['bind']['id'])) {
            throw new \Exception('Not found', 404);
        } else {
            throw new \Exception('No Content', 204);
        }
    }

    /**
     * Update article
     *
     * @param  number     $id
     * @param  array      $data
     * @throws \Exception
     * @return array
     */
    public function restUpdate($id, $data)
    {
        $article = Article::findFirstById((int) $id);

        if (!$article) {
            throw new \Exception('Not found', 404);
        }

        $article->setArticleIsPublished($data[0]['article_is_published']);

        if (false === $article->update()) {
            foreach ($article->getMessages() as $message) {
                throw new \Exception($message->getMessage(), 500);
            }
        }

        return $article->toArray();
    }

    /**
     * Delete article
     *
     * @param  number     $id
     * @throws \Exception
     * @return boolean
     */
    public function restDelete($id)
    {
        $article = Article::findFirstById((int) $id);

        if (!$article) {
            throw new \Exception('Not found', 404);
        }

        if (false === $article->delete()) {
            foreach ($article->getMessages() as $message) {
                throw new \Exception($message->getMessage(), 500);
            }
        }

        return true;
    }

    /**
     * Create a new article
     *
     * @param  array $data
     * @return array
     */
    public function restCreate($data)
    {
        $result = $this->create($data);

        return $result->toArray();
    }

    /**
     * Create a new article
     *
     * @param  array                           $data
     * @param  string                          $language
     * @return string|\App\Core\Models\Article
     */
    public function create($input_data)
    {
        $default_data = array(
            'article_user_id' => 1,
            'article_is_published' => 0,
            'translations' => array(
                'en' => array(
                    'article_translation_short_title' => 'Short title',
                    'article_translation_long_title' => 'Long title',
                    'article_translation_description' => 'Description',
                    'article_translation_slug' => '',
                    'article_translation_lang' => 'en',
                ),
            ),
            'categories' => array(),
            'hashtags' => array(),
        );

        $data = array_merge($default_data, $input_data);

        $article = new Article();
        $article->setArticleIsPublished($data['article_is_published']);

        $articleTranslations = array();

        foreach ($data['translations'] as $lang => $translation) {
            $tmp = new ArticleTranslation();
            $tmp->assign($translation);
            array_push($articleTranslations, $tmp);
        }

        if (count($data['categories']) > 0) {
            $article->categories = Category::find([
                "id IN (".implode(',', $data['categories']).")",
            ])->filter(function ($category) {
                return $category;
            });
        }

        if (count($data['hashtags']) > 0) {
            $article->hashtags = Hashtag::find([
                "id IN (".implode(',', $data['hashtags']).")",
            ])->filter(function ($hashtag) {
                return $hashtag;
            });
        }

        $user = User::findFirstById((int) $data['article_user_id']);

        if (!$user) {
            throw new \Exception('User not found', 404);
        }

        $article->setArticleUserId($data['article_user_id']);

        $article->translations = $articleTranslations;

        return $this->save($article, 'create');
    }

    /**
     * Update an existing article
     *
     * @param  number     $id
     * @param  array      $data
     * @throws \Exception
     * @return unknown
     */
    public function update($id, $data)
    {
        $article = Article::findFirstById($id);

        if (!$article) {
            throw new \Exception('Article not found', 404);
        }

        $article->setArticleShortTitle($data['article_short_title']);
        $article->setUpdatedAt(new \Phalcon\Db\RawValue('NOW()'));

        if (false === $article->update()) {
            foreach ($article->getMessages() as $message) {
                $error[] = (string) $message;
            }

            throw new \Exception(json_encode($error));
        }

        return $article;
    }

    /**
     * Delete articles
     *
     * @param  number     $id
     * @throws \Exception
     * @return boolean
     */
    public function delete($id)
    {
        $article = Article::findFirstById($id);

        if (!$article) {
            throw new \Exception('Article not found', 404);
        }

        if (false === $article->delete()) {
            foreach ($article->getMessages() as $message) {
                $error[] = (string) $message;
            }

            throw new \Exception(json_encode($error));
        }

        return true;
    }
}
